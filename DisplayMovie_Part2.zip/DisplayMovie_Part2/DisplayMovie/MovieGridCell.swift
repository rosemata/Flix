//
//  MovieGridCell.swift
//  DisplayMovie
//
//  Created by Roselle Mata on 9/30/22.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
